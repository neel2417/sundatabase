package java;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class CreateCustomerExample {

    public static void main(String[] args) throws IOException {
        // Customer creation API URL
        String createCustomerURL = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=create";

        // Bearer token received from the authentication API call
        String bearerToken = "dGVzdEBzdW5iYXNlZGF0YS5jb206VGVzdEAxMjM=";

        // Create JSON body for customer creation request
        String requestBody = "{ \"first_name\": \"Jane\", \"last_name\": \"Doe\", \"street\": \"Elvnu Street\", "
                + "\"address\": \"H no 2 \", \"city\": \"Delhi\", \"state\": \"Delhi\", \"email\": \"sam@gmail.com\", "
                + "\"phone\": \"12345678\" }";

        // Send customer creation request
        URL url = new URL(createCustomerURL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + bearerToken);
        conn.setDoOutput(true);

        conn.getOutputStream().write(requestBody.getBytes());

        // Check response code
        if (conn.getResponseCode() == HttpURLConnection.HTTP_CREATED) {
            System.out.println("Customer successfully created.");
        } else if (conn.getResponseCode() == HttpURLConnection.HTTP_BAD_REQUEST) {
            System.err.println("Customer creation failed. First Name or Last Name is missing.");
        } else {
            System.err.println("Customer creation failed. Status Code: " + conn.getResponseCode());
        }
    }
}

