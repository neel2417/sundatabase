package java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetCustomerListExample {

    public static void main(String[] args) throws IOException {
        // Customer list API URL
        String getCustomerListURL = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=get_customer_list";

        // Bearer token received from the authentication API call
        String bearerToken = "dGVzdEBzdW5iYXNlZGF0YS5jb206VGVzdEAxMjM=";

        // Send get customer list request
        URL url = new URL(getCustomerListURL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Bearer " + bearerToken);

        // Check response code
        if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            // Read and parse the response to get the customer list
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            StringBuilder response = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            System.out.println("Customer List:");
            System.out.println(response.toString());
        } else {
            System.err.println("Failed to get the customer list. Status Code: " + conn.getResponseCode());
        }
    }
}
