package java;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class DeleteCustomerExample {

    public static void main(String[] args) {
        // Customer deletion API URL with customer's UUID to be replaced
        String deleteCustomerURL = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=delete&uuid=customer_uuid_here";

        // Bearer token received from the authentication API call
        String bearerToken = "dGVzdEBzdW5iYXNlZGF0YS5jb206VGVzdEAxMjM=";

        try {
            // Send delete customer request
            URL url = new URL(deleteCustomerURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET"); // Use GET method for customer deletion (Replace with the appropriate method if provided by the API)
            conn.setRequestProperty("Authorization", "Bearer " + bearerToken);

            // Check response code
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                System.out.println("Customer successfully deleted.");
            } else if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                System.err.println("UUID not found.");
            } else if (responseCode == HttpURLConnection.HTTP_INTERNAL_ERROR) {
                System.err.println("Error while deleting the customer.");
            } else {
                System.err.println("Failed to delete the customer. Status Code: " + responseCode);
            }
        } catch (IOException e) {
            System.err.println("An error occurred during the API call: " + e.getMessage());
        }
    }
}

