package java;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class AuthenticationExample {

    public static void main(String[] args) throws IOException {
        // Authentication API URL
        String authURL = "https://qa2.sunbasedata.com/sunbase/portal/api/assignment_auth.jsp";

        String loginId = "test@sunbasedata.com";
        String password = "Test@123";

        // Create JSON body for authentication request
        String requestBody = String.format("{\"login_id\": \"%s\", \"password\": \"%s\"}", loginId, password);

        // Send authentication request
        URL url = new URL(authURL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        conn.getOutputStream().write(requestBody.getBytes());

        // Check response code
        if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            // Get bearer token from response
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            StringBuilder response = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            String bearerToken = response.toString();
            // Continue with further API calls using this bearer token.
            // For simplicity, we will print the token here.
            System.out.println("Bearer Token: " + bearerToken);
        } else {
            // Handle error cases
            System.err.println("Authentication failed. Status Code: " + conn.getResponseCode());
        }
    }
}
